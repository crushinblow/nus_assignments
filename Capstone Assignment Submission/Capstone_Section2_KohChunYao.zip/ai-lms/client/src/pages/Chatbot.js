import React from 'react';

function Chatbot() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>AI Chatbot</h2>
      <p>Chatbot integration coming soon...</p>
    </div>
  );
}

export default Chatbot;
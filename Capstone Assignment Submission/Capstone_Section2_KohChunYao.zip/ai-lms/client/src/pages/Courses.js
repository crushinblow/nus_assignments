import React from 'react';

function Courses() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Available Courses</h2>
      <p>Course list will go here...</p>
    </div>
  );
}

export default Courses;
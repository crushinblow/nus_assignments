// feature.js file
function addNumbers(a, b) {
    return a + b;
    
}

console.log(addNumbers(4, 5));  // save file and run , should see 9
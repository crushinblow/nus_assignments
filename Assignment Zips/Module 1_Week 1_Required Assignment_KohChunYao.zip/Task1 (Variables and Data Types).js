// Declare a variable x and assign the value 10 to it  (numeric data type)
var x = 10;

// Declare another variable y with the value "Hello" (text)
var y = "Hello";

// Concatenate both values and store the result in a new variable 'result'
var result = y + x;
// + operator joins the string "Hello" with the number 10
// JavaScript will auto converts 10 to a string to show result as "Hello10"
// Used console.log(result);  to print "Hello10" in the browser console to check

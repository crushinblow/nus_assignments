// Define the function greetUser with a parameter 'name'
function greetUser(name) {
    console.log("Hello, " + name + "!");
}

// Call the function with different names
greetUser("Alice");    // Output: Hello, Alice!
greetUser("Bob");      // Output: Hello, Bob!
greetUser("Charlie");  // Output: Hello, Charlie!




